sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("appointmentapplication.controller.App", {
      onInit() {
      }
  });
});